function Ylm = sph_harmonC(l,m,theta,phi)

m_neg = 0;
if m<0
    m = -m;
    m_neg = 1;
end

Plm = legendre(l,cos(theta));

if l ~= 0
    Plm = reshape(Plm(m+1,:,:),size(phi));
end

a = (2*l+1)*factorial(l-m);
b = 4*pi*factorial(l+m);
C = sqrt(a/b);
Ylm = C .*Plm .*exp(1i*m*phi);

if m_neg
    Ylm = (-1)^m * conj(Ylm);
end

end