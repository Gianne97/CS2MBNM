%
% Files
%   nfsoft_get_num_threads    - Get number of threads used for computation
%   nfsoftmex                 - Gateway routine to the NFSOFT module
