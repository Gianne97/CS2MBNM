%Set Fourier coefficients
function nfsoft_set_f_hat (plan,f_hat)
nfsoftmex('set_f_hat',plan,f_hat)