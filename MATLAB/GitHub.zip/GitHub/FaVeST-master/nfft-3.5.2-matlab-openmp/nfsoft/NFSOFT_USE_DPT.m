function f = NFSOFT_USE_DPT()
f = 4;
end