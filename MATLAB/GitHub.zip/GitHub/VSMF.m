function [M_r, M_th, M_ph, N_r, N_th, N_ph] = VSMF(r, th, ph, l, m, k0, typ)

% The function returns the components of the vector spherical multipole
% functions, M and N.
% M is the magnetic harmonics. It has no radial part
% N is the electric harmonics
% Rows of M and N are
% 1 - radial part
% 2 - component along theta
% 3 - component along phi

if typ == "j" % stationary wave
    radial_function = @(l, x) sph_bess(l, x);
elseif typ == "h1" % inward propagating wave
    radial_function = @(l, x) sph_hankel(l, 1, x);
elseif typ == "h2" % outward propagating wave
    radial_function = @(l, x) sph_hankel(l, 2, x);
else
    error("Wrong value for typ")
end

[m_th, m_ph] = TSMF(th, ph, l, m);
n_th = m_ph;
n_ph =-m_th;

M_r  = zeros(size(th)); % This component vanishes
M_th = radial_function(l, k0*r) * m_th;
M_ph = radial_function(l, k0*r) * m_ph;

N_r  = -l*(l+1)*(radial_function(l, k0*r)/(k0*r)) * sph_harmonC(l,m,th,ph);
N_th = -sph_factor(l,k0,r,typ) * n_th;
N_ph = -sph_factor(l,k0,r,typ) * n_ph;

end