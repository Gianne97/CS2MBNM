function output = sph_factor(l,k,R,typ)

% Computation of the following quantity: (check wolfram alpha)
% (d/dx (x z_l(k*x))) / (k*x)
% D[r*z_l(k*x), r] / (k*r)

% D[r*SphericalHankelH2[l,k*r], r] / (k*r) = (h_l^(2)(k r) + k r (h_(l - 1)^(2)(k r) - h_(l + 1)^(2)(k r)))/(2 k r)

if typ == "j"
    radial_function = @(l, x) sph_bess(l, x);
elseif typ == "h1"
    radial_function = @(l, x) sph_hankel(l, 1, x);
elseif typ == "h2"
    radial_function = @(l, x) sph_hankel(l, 2, x);
else
    error("Wrong value for typ")
end

output = ( radial_function(l, k*R) + k*R*( radial_function(l-1, k*R) - radial_function(l+1, k*R) ) ) ./ ( 2*k*R );

end