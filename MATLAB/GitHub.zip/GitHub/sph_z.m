function radial_function = sph_z(l,k0,R,typ)

if typ == "j"
    radial_function = sph_bess(l, k0*R);
elseif typ == "h1"
    radial_function = sph_hankel(l, 1, k0*R);
elseif typ == "h2"
    radial_function = sph_hankel(l, 2, k0*R);
else
    error("Wrong value for typ")
end
end

