function hank=sph_hankel(n,typ,x)
% Computes the spherical Bessel function for order n
% L. Klinkenbusch, Univ. of Kiel
% 29. Sep. 2019
%
    hank=besselh(n+.5,typ,x)*sqrt(pi/2/x);
end