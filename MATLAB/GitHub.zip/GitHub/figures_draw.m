%% Antenna

% Step model of the antenna
figure
c1 = customAntennaStl(FileName="HornAntenna.stl", Units='mm');
c1.show

% Sides of the box enclosing the antenna
figure
scatter3(SidesMin(:,1),SidesMin(:,2),SidesMin(:,3))
figure
scatter3(SidesMax(:,1),SidesMax(:,2),SidesMax(:,3))

%% Equivalent currents

figure
quiver3(ERS0(:,1),ERS0(:,2),ERS0(:,3), Fields_RS0_t.Ex, Fields_RS0_t.Ey, Fields_RS0_t.Ez)
title("Electric field on the enclosing box without scatterer")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")

figure
quiver3(ERS0(:,1),ERS0(:,2),ERS0(:,3), Fields_RS0_t.Hx, Fields_RS0_t.Hy, Fields_RS0_t.Hz)
title("Magnetic field on the enclosing box without scatterer")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")

figure
quiver3(xSides,ySides,zSides, real(JeR.x), real(JeR.y), real(JeR.z))
title("Equivalent electric current on the enclosing box")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")

figure
quiver3(xSides,ySides,zSides, real(JmR.x), real(JmR.y), real(JmR.z))
title("Equivalent magnetic current on the enclosing box")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")

%% SPHERE - antenna

figure
quiver3(ESS0(:,1),ESS0(:,2),ESS0(:,3), Fields_SS0_t.Ex, Fields_SS0_t.Ey, Fields_SS0_t.Ez)
title("Simulated electric field on the enclosing sphere without scatterer")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")

figure
quiver3(ESS1(:,1),ESS1(:,2),ESS1(:,3), Fields_SS1_t.Ex, Fields_SS1_t.Ey, Fields_SS1_t.Ez)
title("Simulated electric field on the enclosing sphere with scatterer")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")

%% MULTIPOLES - antenna sphere

figure
scatter(azimuth, elevation)
yline(-pi/2)
yline(pi/2)
xline(-pi)
xline(+pi)
xlabel("Azimuth")
ylabel("Elevation")

figure
scatter(PhiTheta(1,:), PhiTheta(2,:))
yline(0)
yline(pi)
xline(0)
xline(2*pi)
xlabel("Phi")
ylabel("Theta")

% Convergence for the flux of the Poynting vector
fig = figure;
ax = axes(fig);
hold on
plot(1:Lmax, Integral_check4_r_par_relError(1,1:end), '*')
plot(2:Lmax, RelDiffSteps, '+')
RelDiffSteps
ax.YScale = "log";
ylabel("Rel. error (%)")
yyaxis right
plot(1:Lmax, real(Integral_check4_r_par), 'o')
yline(Prad_CST,Label="Prad CST",LabelVerticalAlignment="bottom",LabelHorizontalAlignment="center")
ylabel("Power (W)")
yyaxis left
hold off
ax.XLim = [0, Lmax+1];
xlabel("L")
legend("Convergence real part flux of S", "Convergence two consecutive steps", "Real part flux of S", "Location","south")
grid on
box on
set(ax,"FontName","Times New Roman")
% exportgraphics(ax,"figures/MultipoleConvergence.pdf")

close all
fig = figure;
ax = axes(fig);
ax.Units = "centimeters";
ax.Position(3:4) = [7, 4];
hold on
plot(1:Lmax, real(Integral_check4_r_par(1,:)), 'o')
% yline(Prad_CST,Label="Prad CST",LabelVerticalAlignment="bottom",LabelHorizontalAlignment="center")
yyaxis right
plot(2:Lmax, RelDiffSteps, 'k+')
plot(1:Lmax, Integral_check4_r_par_relError(1,1:end), '*')
RelDiffSteps
ax.YScale = "log";
ax.YLim = [1e-6, 1e4];
ax.YTick = 10.^(-5:4:3);
ylabel("Rel. error (%)")
grid(gca,"on")
yyaxis left
hold off

dim = [0.275 0.39 0.05 0.05];
annotation('ellipse',dim)
annotation('arrow',[0.275 0.22],[0.39 0.39]+0.05/2)

dim = [0.4 0.3 0.05 0.05];
annotation('ellipse',dim)
annotation('arrow',[0.4+0.05 0.4+0.05+0.055],[0.3 0.3]+0.05/2)

ylabel("Power (W)")
ax.XLim = [0, Lmax+1];
xlabel("N")
legend("{\itP_a}", "{\itC_s}", "{\itC_t}", "Location","south")
grid on
box on
set(ax,"FontName","Times New Roman")
% exportgraphics(ax,"figures/MultipoleConvergencePaper.pdf")

% Figures of the multipole coefficients
FontSize = 8;
idx_fig = idx_lm(:,1) <= 5;
fig = figure;
ax = axes(fig);
ax.Units = "centimeters";
ax.Position(3:4) = [7, 5];
ax.YScale = "log";
hold on
plot(idx_lm_lin(idx_fig), abs(I_Anm(idx_fig)), 'o')
plot(idx_lm_lin(idx_fig), abs(I_Anm_R(idx_fig)), '*')

plot(idx_lm_lin(idx_fig), abs(I_BZnm(idx_fig)), '+')
plot(idx_lm_lin(idx_fig), abs(I_BZnm_R(idx_fig)), 's')

hold off
grid on
box on
% lg = legend(["{\itA_{nm}}", "{\itA_{nm}^r}", "{\it(Z/}j{\it)B_{nm}}", "{\it(Z/}j{\it)B_{nm}^r}"],'NumColumns',4, Location="northoutside");
lg = legend(["{\ita_{nm}}^a", "{\ita_{nm}}^{a{\it,r}}", "{\it(Z/}j{\it)b_{nm}}^a", "{\it(Z/}j{\it)b_{nm}}^{a{\it,r}}"],'NumColumns',4, Location="northoutside");
xlabel("n^2 + n + m (n \leq 5)")
ylabel("{\it|a_{nm}|} or {\it|(Z/}j{\it) b_{mn}|} (V/m)")
set(ax,"FontName","Times New Roman","FontSize",FontSize)
% exportgraphics(fig,"figures/MagAB.pdf")

FontSize = 8;
idx_fig = idx_lm(:,1) <= 5;
fig = figure;
ax = axes(fig);
ax.Units = "centimeters";
ax.Position(3:4) = [7, 5];
ax.YLim = pi*[-1,1];
hold on
plot(idx_lm_lin(idx_fig), angle(I_Anm(idx_fig)), 'o')
plot(idx_lm_lin(idx_fig), angle(I_Anm_R(idx_fig)), '*')

plot(idx_lm_lin(idx_fig), angle(I_BZnm(idx_fig)), '+')
plot(idx_lm_lin(idx_fig), angle(I_BZnm_R(idx_fig)), 's')

hold off
ax.YTick = pi*(-1:0.5:1);
ax.YTickLabel = ["-\pi", "-\pi/2", "0", "\pi/2", "\pi"];
grid on
box on
% lg = legend(["{\itA_{nm}}", "{\itA_{nm}^r}", "{\it(Z/}j{\it)B_{nm}}", "{\it(Z/}j{\it)B_{nm}^r}"],'NumColumns',4, Location="northoutside");
% lg = legend(["{\ita_{nm}}^a", "{\ita_{nm}}^{a{\it,r}}", "{\it(Z/}j{\it)b_{nm}}^a", "{\it(Z/}j{\it)b_{nm}}^{a{\it,r}}"],'NumColumns',4, Location="northoutside");
xlabel("n^2 + n + m (n \leq 5)")
ylabel("{\it|a_{nm}|} or {\it|(Z/}j{\it) b_{mn}|} (V/m)")
set(ax,"FontName","Times New Roman","FontSize",FontSize)
% exportgraphics(fig,"figures/MagAB.pdf")

% Figures of the multipole coefficients
idx_fig = idx_lm(:,1) <= 5;
fig = figure;
ax = axes(fig);
hold on
plot(idx_lm_lin(idx_fig), abs(I_Anm(idx_fig)), '-o')
plot(idx_lm_lin(idx_fig), abs(I_Anm_R(idx_fig)), '-o')
yyaxis right
help = 100*abs((I_Anm_R - I_Anm)./I_Anm);
plot(idx_lm_lin(idx_fig), abs(help(idx_fig)), '-o')
ylabel("100*|A_{nm}^{'} - A_{nm}|/|A_{nm}|")
yyaxis left
hold off
grid on
box on
legend(["From transverse components of E, A_{nm}", "From radial components of E and H, A_{nm}^{'}", "Relative error"], Location="north")
xlabel("n^2 + n + m")
ylabel("|A_{nm}| (V/m)")
title("Magnitude of A_{nm}")
% exportgraphics(fig,"figures/MagA.pdf")

fig = figure;
ax = axes(fig);
hold on
plot(idx_lm_lin(idx_fig), abs(I_BZnm(idx_fig)), '-o')
plot(idx_lm_lin(idx_fig), abs(I_BZnm_R(idx_fig)), '-o')
yyaxis right
help = 100*abs((I_BZnm_R - I_BZnm)./I_BZnm);
plot(idx_lm_lin(idx_fig), abs(help(idx_fig)), '-o')
ylabel("100*|B_{nm}^{'} - B_{nm}|/|B_{nm}|")
yyaxis left
hold off
grid on
box on
legend(["From transverse components of E, (Z/j)B_{nm}", "From radial components of E and H, (Z/j)B_{nm}^{'}", "Relative error"], Location="north")
xlabel("n^2 + n + m")
ylabel("|(Z/j) B_{mn}| (V/m)")
title("Magnitude of (Z/j) B_{mn}")
% exportgraphics(fig,"figures/MagB.pdf")

fig = figure;
ax = axes(fig);
ax.YLim = [-pi, pi];
hold on
plot(idx_lm_lin(idx_fig), angle(I_Anm(idx_fig)), '-o')
plot(idx_lm_lin(idx_fig), angle(I_Anm_R(idx_fig)), '-o')
hold off
grid on
box on
legend(["A_{nm}", "A_{nm}^{'}"], Location="southwest")
xlabel("n^2 + n + m")
ylabel("angle(A_{mn}) (rad)")
title("Phase of A_{mn}")
% exportgraphics(fig,"figures/PhA.pdf")

fig = figure;
ax = axes(fig);
ax.YLim = [-pi, pi];
hold on
plot(idx_lm_lin(idx_fig), angle(I_BZnm(idx_fig)), '-o')
plot(idx_lm_lin(idx_fig), angle(I_BZnm_R(idx_fig)), '-o')
hold off
grid on
box on
legend(["(Z/j)B_{nm}", "(Z/j)B_{nm}^{'}"], Location="southwest")
xlabel("n^2 + n + m")
ylabel("angle((Z/j) B_{mn}) (rad)")
title("Phase of (Z/j) B_{mn}")
% exportgraphics(fig,"figures/PhB.pdf")

fig = figure;
ax = axes(fig);
hold on
plot(idx_lm_lin(idx_fig), abs(I_Anm(idx_fig)), '-o')
plot(idx_lm_lin(idx_fig), abs(I_Anm_R(idx_fig)), '-o')

yyaxis right
aaa = gca;
aaa.YScale = "log";
help = 100*abs((I_Anm_R - I_Anm)./I_Anm);
plot(idx_lm_lin(idx_fig), abs(help(idx_fig)), '-o')
ylabel("100*|A_{nm}^{'} - A_{nm}|/|A_{nm}|")
yyaxis left

hold off
grid on
box on
ax.YScale = "log";
xlabel("n^2 + n + m")
ylabel("|A_{mn}| (V/m)")

fig = figure;
ax = axes(fig);
hold on
plot(idx_lm_lin(idx_fig), abs(I_BZnm(idx_fig)), '-o')
plot(idx_lm_lin(idx_fig), abs(I_BZnm_R(idx_fig)), '-o')

yyaxis right
aaa = gca;
aaa.YScale = "log";
help = 100*abs((I_BZnm_R - I_BZnm)./I_BZnm);
plot(idx_lm_lin(idx_fig), abs(help(idx_fig)), '-o')
ylabel("100*|B_{nm}^{'} - B_{nm}|/|B_{nm}|")
yyaxis left

hold off
grid on
box on
ax.YScale = "log";
xlabel("n^2 + n + m")
ylabel("|(Z/j) B_{mn}| (V/m)")

%% COMPARISON - sphere enclosing the antenna

% magnitude
fig = figure;
quiver3(ESS0(:,1),ESS0(:,2),ESS0(:,3)+zc*m2mm, abs(Fields_SS0.Ex), abs(Fields_SS0.Ey), abs(Fields_SS0.Ez))
title("Original electric field on the sphere enclosing the antenna - magnitude")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")
% exportgraphics(fig, "figures/OrigE.pdf")
% saveas(fig, "figures/OrigE.fig", 'fig')

fig = figure;
quiver3(ESS0(:,1),ESS0(:,2),ESS0(:,3)+zc*m2mm, abs(vEr_Cc(1,:))', abs(vEr_Cc(2,:))', abs(vEr_Cc(3,:))')
title("Reconstructed electric field on the sphere enclosing the antenna - magnitude")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")
% exportgraphics(fig, "figures/RecE.pdf")
% saveas(fig, "figures/RecE.fig", 'fig')

fig = figure;
quiver3(ESS0(:,1),ESS0(:,2),ESS0(:,3)+zc*m2mm, abs(Fields_SS0.Hx), abs(Fields_SS0.Hy), abs(Fields_SS0.Hz))
title("Original magnetic field on the sphere enclosing the antenna - magnitude")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")
% exportgraphics(fig, "figures/OrigH.pdf")
% saveas(fig, "figures/OrigH.fig", 'fig')

fig = figure;
quiver3(ESS0(:,1),ESS0(:,2),ESS0(:,3)+zc*m2mm, abs(vHr_Cc(1,:))', abs(vHr_Cc(2,:))', abs(vHr_Cc(3,:))')
title("Reconstructed magnetic field on the sphere enclosing the antenna - magnitude")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")
% exportgraphics(fig, "figures/RecH.pdf")
% saveas(fig, "figures/RecH.fig", 'fig')

difference.Ex = Fields_SS0.Ex - vEr_Cc(1,:).';
difference.Ey = Fields_SS0.Ey - vEr_Cc(2,:).';
difference.Ez = Fields_SS0.Ez - vEr_Cc(3,:).';
difference.Hx = Fields_SS0.Hx - vHr_Cc(1,:).';
difference.Hy = Fields_SS0.Hy - vHr_Cc(2,:).';
difference.Hz = Fields_SS0.Hz - vHr_Cc(3,:).';

[max(abs(Fields_SS0.Ex)), max(abs(Fields_SS0.Ey)), max(abs(Fields_SS0.Ez))]
[max(abs(vEr_Cc(1,:))),   max(abs(vEr_Cc(2,:))),   max(abs(vEr_Cc(3,:)))]
[max(abs(difference.Ex)), max(abs(difference.Ey)), max(abs(difference.Ez))]
100*[max(abs(difference.Ex)), max(abs(difference.Ey)), max(abs(difference.Ez))]./[max(abs(Fields_SS0.Ex)), max(abs(Fields_SS0.Ey)), max(abs(Fields_SS0.Ez))]

% difference
fig = figure;
quiver3(ESS0(:,1),ESS0(:,2),ESS0(:,3)+zc*m2mm, abs(difference.Ex), abs(difference.Ey), abs(difference.Ez))
title("Difference electric field on the sphere enclosing the antenna")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")
% exportgraphics(fig, "figures/OrigE.pdf")
% saveas(fig, "figures/OrigE.fig", 'fig')

fig = figure;
quiver3(ESS0(:,1),ESS0(:,2),ESS0(:,3)+zc*m2mm, abs(difference.Hx), abs(difference.Hy), abs(difference.Hz))
title("Difference magnetic field on the sphere enclosing the antenna")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Global Ref. Sys.")
% exportgraphics(fig, "figures/OrigH.pdf")
% saveas(fig, "figures/OrigH.fig", 'fig')

%% 2D field visualization

Fields_SS0r_Cc.Ex = vEr_Cc(1,:);
Fields_SS0r_Cc.Ey = vEr_Cc(2,:);
Fields_SS0r_Cc.Ez = vEr_Cc(3,:);
Fields_SS0r_Cc.Hx = vHr_Cc(1,:);
Fields_SS0r_Cc.Hy = vHr_Cc(2,:);
Fields_SS0r_Cc.Hz = vHr_Cc(3,:);

[flow_E, flow_rec_E, flow_err_E, flow_H, flow_rec_H, flow_err_H] = Visualization2D(Fields_SS0, Fields_SS0r_Cc, PhiTheta);

%% COMPARISON - scatterer surface

% magnitude

fig = figure;
ax = axes(fig);
% scatter3(ESS0(:,1),ESS0(:,2),ESS0(:,3))
quiver3((ESSS0(:,1)-x0*m2mm),(ESSS0(:,2)-y0*m2mm),(ESSS0(:,3)-z0*m2mm-zc*m2mm), abs(Fields_SSS0.Ex), abs(Fields_SSS0.Ey), abs(Fields_SSS0.Ez))
title("FWS electric field on the scatterer surface without scatterer")
xlabel("x (mm)")
ylabel("y (mm)")
% zlabel("z (mm) Global Ref. Sys.")
zlabel("z (mm) Scatterer Ref. Sys.")
ax.ZLim = [-30, 30];

fig = figure;
ax = axes(fig);
% quiver3((x)*m2mm,(y)*m2mm,(z)*m2mm, abs(E_metB.x).', abs(E_metB.y).', abs(E_metB.z).') % +z0S*m2mm
quiver3((x)*m2mm,(y)*m2mm,(z)*m2mm, abs(vEr_metB(1,:)).', abs(vEr_metB(2,:)).', abs(vEr_metB(3,:)).') % +z0S*m2mm
title("Reconstructed electric field on the scatterer surface without scatterer - MetB")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Scatterer Ref. Sys.")
% exportgraphics(fig, "figures/OrigE.pdf")
% saveas(fig, "figures/OrigE.fig", 'fig')
ax.ZLim = [-30, 30];

% Magnetic field

fig = figure;
ax = axes(fig);
% scatter3(ESS0(:,1),ESS0(:,2),ESS0(:,3))
quiver3((ESSS0(:,1)-x0*m2mm),(ESSS0(:,2)-y0*m2mm),(ESSS0(:,3)-z0*m2mm-zc*m2mm), abs(Fields_SSS0.Hx), abs(Fields_SSS0.Hy), abs(Fields_SSS0.Hz))
title("FWS magnetic field on the scatterer surface without scatterer")
xlabel("x (mm)")
ylabel("y (mm)")
% zlabel("z (mm) Global Ref. Sys.")
zlabel("z (mm) Scatterer Ref. Sys.")
ax.ZLim = [-30, 30];

fig = figure;
ax = axes(fig);
quiver3((x)*m2mm,(y)*m2mm,(z)*m2mm, abs(H_metB.x).', abs(H_metB.y).', abs(H_metB.z).') % +z0S*m2mm
quiver3((x)*m2mm,(y)*m2mm,(z)*m2mm, abs(vHr_metB(1,:)).', abs(vHr_metB(2,:)).', abs(vHr_metB(3,:)).') % +z0S*m2mm
title("Reconstructed magnetic field on the scatterer surface without scatterer - MetB")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Scatterer Ref. Sys.")
% exportgraphics(fig, "figures/OrigE.pdf")
% saveas(fig, "figures/OrigE.fig", 'fig')
ax.ZLim = [-30, 30];

%% 2D field visualization

FieldsMetB_FWS.Ex = E_metB.x;
FieldsMetB_FWS.Ey = E_metB.y;
FieldsMetB_FWS.Ez = E_metB.z;
FieldsMetB_FWS.Hx = H_metB.x;
FieldsMetB_FWS.Hy = H_metB.y;
FieldsMetB_FWS.Hz = H_metB.z;

FieldsMetB_ME.Ex = vEr_metB(1,:);
FieldsMetB_ME.Ey = vEr_metB(2,:);
FieldsMetB_ME.Ez = vEr_metB(3,:);
FieldsMetB_ME.Hx = vHr_metB(1,:);
FieldsMetB_ME.Hy = vHr_metB(2,:);
FieldsMetB_ME.Hz = vHr_metB(3,:);

% FLW and ME for Method B
[flow_E_FWS_MB, flow_rec_E_FWS_MB, flow_err_E_FWS_MB, flow_H_FWS_MB, flow_rec_H_FWS_MB, flow_err_H_FWS_MB] = Visualization2D(Fields_SSS0, FieldsMetB_ME, PhiTheta);

% Method B (no ME) and ME for Method B
% Visualization2D(FieldsMetB_FWS, FieldsMetB_ME, PhiTheta);

if PointCase == "A"
    exportgraphics(flow_E_FWS_MB, "figures/fig_flow_E_FWS_MB_caseA.pdf")
    exportgraphics(flow_rec_E_FWS_MB, "figures/fig_flow_rec_E_FWS_MB_caseA.pdf")
    exportgraphics(flow_err_E_FWS_MB, "figures/fig_flow_err_E_FWS_MB_caseA.pdf")

    exportgraphics(flow_H_FWS_MB, "figures/fig_flow_H_FWS_MB_caseA.pdf")
    exportgraphics(flow_rec_H_FWS_MB, "figures/fig_flow_rec_H_FWS_MB_caseA.pdf")
    exportgraphics(flow_err_H_FWS_MB, "figures/fig_flow_err_H_FWS_MB_caseA.pdf")
elseif PointCase == "B"
    exportgraphics(flow_E_FWS_MB, "figures/fig_flow_E_FWS_MB_caseB.pdf")
    exportgraphics(flow_rec_E_FWS_MB, "figures/fig_flow_rec_E_FWS_MB_caseB.pdf")
    exportgraphics(flow_err_E_FWS_MB, "figures/fig_flow_err_E_FWS_MB_caseB.pdf")

    exportgraphics(flow_H_FWS_MB, "figures/fig_flow_H_FWS_MB_caseB.pdf")
    exportgraphics(flow_rec_H_FWS_MB, "figures/fig_flow_rec_H_FWS_MB_caseB.pdf")
    exportgraphics(flow_err_H_FWS_MB, "figures/fig_flow_err_H_FWS_MB_caseB.pdf")
elseif PointCase == "C"
    exportgraphics(flow_E_FWS_MB, "figures/fig_flow_E_FWS_MB_caseC.pdf")
    exportgraphics(flow_rec_E_FWS_MB, "figures/fig_flow_rec_E_FWS_MB_caseC.pdf")
    exportgraphics(flow_err_E_FWS_MB, "figures/fig_flow_err_E_FWS_MB_caseC.pdf")

    exportgraphics(flow_H_FWS_MB, "figures/fig_flow_H_FWS_MB_caseC.pdf")
    exportgraphics(flow_rec_H_FWS_MB, "figures/fig_flow_rec_H_FWS_MB_caseC.pdf")
    exportgraphics(flow_err_H_FWS_MB, "figures/fig_flow_err_H_FWS_MB_caseC.pdf")
end

%% MULTIPOLES - scatterer sphere

LmaxAT = 15; % From the convergence of the multipoles
idxAT = idx_lm(:,1)<=LmaxAT;
idx_fig = idx_lm(:,1) <= 4;

% Figures of the multipole coefficients
fig = figure;
ax = axes(fig);
ax.YScale = 'log';
hold on
plot(idx_lm_lin(idx_fig), abs(I_Anm_SSS0(idx_fig)), '^')
plot(idx_lm_lin(idx_fig), abs(I_Anm_MB(idx_fig)), '*')
hold off
grid on
box on
legend(["CST", "Met."], Location="south")
set(ax,"FontName","Times New Roman")
xlabel("n^2 + n + m")
ylabel("Mag. (V/m)")
title("A_{nm}")
% exportgraphics(fig,"figures/MagA_Sphere.pdf")
% exportgraphics(fig,"figures/MagA_Sphere_caseB.pdf")

fig = figure;
ax = axes(fig);
ax.YScale = 'log';
hold on
plot(idx_lm_lin(idx_fig), abs(I_BZnm_SSS0(idx_fig)), '^')
plot(idx_lm_lin(idx_fig), abs(I_BZnm_MB(idx_fig)), 's')
hold off
grid on
box on
legend(["CST", "Met."], Location="south")
set(ax,"FontName","Times New Roman")
xlabel("n^2 + n + m")
ylabel("Mag. (V/m)")
title("B_{mn}")
% exportgraphics(fig,"figures/MagB_Sphere.pdf")
% exportgraphics(fig,"figures/MagB_Sphere_caseB.pdf")

% Figures of the multipole coefficients
idx_fig = idx_lm(:,1) <= 5;
fig = figure;
ax = axes(fig);
hold on
plot(idx_lm_lin(idx_fig), angle(I_Anm_SSS0(idx_fig)), '^')
plot(idx_lm_lin(idx_fig), angle(I_Anm_MB(idx_fig)), '*')
hold off
grid on
box on
ax.YLim = pi*[-1, 1];
ax.YTick = pi*(-1:0.5:1);
ax.YTickLabel = ["-\pi", "-\pi/2", "0", "\pi/2", "\pi"];
legend(["CST", "Met."], Location="south")
set(ax,"FontName","Times New Roman")
xlabel("n^2 + n + m")
ylabel("Pha. (deg)")
title("A_{nm}")
% exportgraphics(fig,"figures/PhaA_Sphere.pdf")

fig = figure;
ax = axes(fig);
hold on
plot(idx_lm_lin(idx_fig), angle(I_BZnm_SSS0(idx_fig)), '^')
plot(idx_lm_lin(idx_fig), angle(I_BZnm_MB(idx_fig)), '*')
hold off
grid on
box on
ax.YLim = pi*[-1, 1];
ax.YTick = pi*(-1:0.5:1);
ax.YTickLabel = ["-\pi", "-\pi/2", "0", "\pi/2", "\pi"];
legend(["CST", "Met."], Location="south")
set(ax,"FontName","Times New Roman")
xlabel("n^2 + n + m")
ylabel("Pha. (deg)")
title("(Z/j) B_{mn}")
% exportgraphics(fig,"figures/PhaB_Sphere.pdf")

%% Inside the sphere

% Figures of the multipole coefficients
idx_fig = idx_lm(:,1) <= 4;
fig = figure;
ax = axes(fig);
ax.YScale = 'log';
hold on
% plot(idx_lm_lin(idx_fig), abs(I_Anm_SSS1(idx_fig)), '^')
plot(idx_lm_lin(idx_fig), abs(I_Anm_R_SSS1(idx_fig)), 's')
plot(idx_lm_lin(idx_fig), abs(I_Anm_MB_inSphere(idx_fig)), '*')
hold off
grid on
box on
legend(["CST", "Met. B"], Location="south")
% legend(["CST", "CST R", "Met. B"], Location="south")
set(ax,"FontName","Times New Roman")
xlabel("n^2 + n + m")
ylabel("Mag. (V/m)")
title("A_{nm}")
% exportgraphics(fig,"figures/MagA_Sphere.pdf")
% exportgraphics(fig,"figures/MagA_Sphere_caseB.pdf")

fig = figure;
ax = axes(fig);
ax.YScale = 'log';
hold on
% plot(idx_lm_lin(idx_fig), abs(I_BZnm_SSS1(idx_fig)), '^')
plot(idx_lm_lin(idx_fig), abs(I_BZnm_R_SSS1(idx_fig)), 's')
plot(idx_lm_lin(idx_fig), abs(I_BZnm_MB_inSphere(idx_fig)), '*')
hold off
grid on
box on
legend(["CST", "Met. B"], Location="south")
% legend(["CST", "CST R", "Met. B"], Location="south")
set(ax,"FontName","Times New Roman")
xlabel("n^2 + n + m")
ylabel("Mag. (V/m)")
title("B_{mn}")
% exportgraphics(fig,"figures/MagB_Sphere.pdf")
% exportgraphics(fig,"figures/MagB_Sphere_caseB.pdf")


% Figures of the multipole coefficients
fig = figure;
ax = axes(fig);
% ax.YScale = 'log';
hold on
% plot(idx_lm_lin(idx_fig), angle(I_Anm_SSS1(idx_fig)), '^')
plot(idx_lm_lin(idx_fig), angle(I_Anm_R_SSS1(idx_fig)), 's')
plot(idx_lm_lin(idx_fig), angle(I_Anm_MB_inSphere(idx_fig)), '*')
hold off
grid on
box on
legend(["CST", "Met. B"], Location="south")
% legend(["CST", "CST R", "Met. B"], Location="south")
set(ax,"FontName","Times New Roman")
xlabel("n^2 + n + m")
ylabel("Pha. (V/m)")
title("A_{nm}")
% exportgraphics(fig,"figures/MagA_Sphere.pdf")
% exportgraphics(fig,"figures/MagA_Sphere_caseB.pdf")

fig = figure;
ax = axes(fig);
% ax.YScale = 'log';
hold on
% plot(idx_lm_lin(idx_fig), angle(I_BZnm_SSS1(idx_fig)), '^')
plot(idx_lm_lin(idx_fig), angle(I_BZnm_R_SSS1(idx_fig)), 's')
plot(idx_lm_lin(idx_fig), angle(I_BZnm_MB_inSphere(idx_fig)), '*')
hold off
grid on
box on
legend(["CST", "Met. B"], Location="south")
% legend(["CST", "CST R", "Met. B"], Location="south")
set(ax,"FontName","Times New Roman")
xlabel("n^2 + n + m")
ylabel("Pha. (V/m)")
title("B_{mn}")
% exportgraphics(fig,"figures/MagB_Sphere.pdf")
% exportgraphics(fig,"figures/MagB_Sphere_caseB.pdf")

%% COMPARISON - scatterer surface

[x_iS,y_iS,z_iS] = sph2cart(azimuth,elevation,R_test_iS);

% magnitude

fig = figure;
ax = axes(fig);
% scatter3(ESS0(:,1),ESS0(:,2),ESS0(:,3))
quiver3((ESSS1(:,1)-x0*m2mm),(ESSS1(:,2)-y0*m2mm),(ESSS1(:,3)-z0*m2mm-zc*m2mm), abs(Fields_SSS1.Ex), abs(Fields_SSS1.Ey), abs(Fields_SSS1.Ez))
title("FWS electric field on the scatterer surface without scatterer")
xlabel("x (mm)")
ylabel("y (mm)")
% zlabel("z (mm) Global Ref. Sys.")
zlabel("z (mm) Scatterer Ref. Sys.")
ax.ZLim = [-30, 30];

fig = figure;
ax = axes(fig);
% quiver3((x)*m2mm,(y)*m2mm,(z)*m2mm, abs(E_metB.x).', abs(E_metB.y).', abs(E_metB.z).') % +z0S*m2mm
quiver3((x_iS)*m2mm,(y_iS)*m2mm,(z_iS)*m2mm, abs(vEr_S1_metB(1,:)).', abs(vEr_S1_metB(2,:)).', abs(vEr_S1_metB(3,:)).') % +z0S*m2mm
title("Reconstructed electric field on the scatterer surface without scatterer - MetB")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Scatterer Ref. Sys.")
% exportgraphics(fig, "figures/OrigE.pdf")
% saveas(fig, "figures/OrigE.fig", 'fig')
ax.ZLim = [-30, 30];

% % Magnetic field

fig = figure;
ax = axes(fig);
% scatter3(ESS0(:,1),ESS0(:,2),ESS0(:,3))
quiver3((ESSS1(:,1)-x0*m2mm),(ESSS1(:,2)-y0*m2mm),(ESSS1(:,3)-z0*m2mm-zc*m2mm), abs(Fields_SSS1.Hx), abs(Fields_SSS1.Hy), abs(Fields_SSS1.Hz))
title("FWS magnetic field on the scatterer surface without scatterer")
xlabel("x (mm)")
ylabel("y (mm)")
% zlabel("z (mm) Global Ref. Sys.")
zlabel("z (mm) Scatterer Ref. Sys.")
ax.ZLim = [-30, 30];

fig = figure;
ax = axes(fig);
% quiver3((x)*m2mm,(y)*m2mm,(z)*m2mm, abs(H_metB.x).', abs(H_metB.y).', abs(H_metB.z).') % +z0S*m2mm
quiver3((x_iS)*m2mm,(y_iS)*m2mm,(z_iS)*m2mm, abs(vHr_S1_metB(1,:)).', abs(vHr_S1_metB(2,:)).', abs(vHr_S1_metB(3,:)).') % +z0S*m2mm
title("Reconstructed magnetic field on the scatterer surface without scatterer - MetB")
xlabel("x (mm)")
ylabel("y (mm)")
zlabel("z (mm) Scatterer Ref. Sys.")
% exportgraphics(fig, "figures/OrigE.pdf")
% saveas(fig, "figures/OrigE.fig", 'fig')
ax.ZLim = [-30, 30];

%% 2D field visualization

FieldsMetB_FWS.Ex = Fields_SSS1.Ex;
FieldsMetB_FWS.Ey = Fields_SSS1.Ey;
FieldsMetB_FWS.Ez = Fields_SSS1.Ez;
FieldsMetB_FWS.Hx = Fields_SSS1.Hx;
FieldsMetB_FWS.Hy = Fields_SSS1.Hy;
FieldsMetB_FWS.Hz = Fields_SSS1.Hz;

FieldsMetB_ME.Ex = vEr_S1_metB(1,:);
FieldsMetB_ME.Ey = vEr_S1_metB(2,:);
FieldsMetB_ME.Ez = vEr_S1_metB(3,:);
FieldsMetB_ME.Hx = vHr_S1_metB(1,:);
FieldsMetB_ME.Hy = vHr_S1_metB(2,:);
FieldsMetB_ME.Hz = vHr_S1_metB(3,:);

% FLW and ME for Method B
[flow_E_FWS_MB, flow_rec_E_FWS_MB, flow_err_E_FWS_MB, flow_H_FWS_MB, flow_rec_H_FWS_MB, flow_err_H_FWS_MB] = Visualization2D(Fields_SSS1, FieldsMetB_ME, PhiTheta);

% Method B (no ME) and ME for Method B
% Visualization2D(FieldsMetB_FWS, FieldsMetB_ME, PhiTheta);

%% Functions

function [flow_E, flow_rec_E, flow_error_E, flow_H, flow_rec_H, flow_error_H] = Visualization2D(Field1, Field2, PhiTheta)

addpath(genpath(strcat(pwd, "\FaVeST-master")));

if isstruct(Field1)
    Q1 = abs([Field1.Ex(:), Field1.Ey(:), Field1.Ez(:)]);
else
    Q1 = transpose(abs(Field1));
end

if isstruct(Field2)
    Q2 = abs([Field2.Ex(:), Field2.Ey(:), Field2.Ez(:)]);
else
    Q2 = transpose(abs(Field2));
end
err_pntwise = abs(Q1 - Q2);

h_Ph = transpose(PhiTheta(1,:));
% h_Ph(h_Ph > pi) = h_Ph(h_Ph > pi) - 2*pi;
h_Th = transpose(PhiTheta(2,:));
% h_Th(h_Th > pi/2) = h_Th(h_Th > pi/2) - pi;

[flow_E, flow_rec_E, flow_error_E] = Visualization_GG(h_Ph,h_Th,Q1,Q2,err_pntwise,0,0);

if isstruct(Field1)
    Q1 = abs([Field1.Hx(:), Field1.Hy(:), Field1.Hz(:)]);
else
    Q1 = transpose(abs(Field1));
end

if isstruct(Field2)
    Q2 = abs([Field2.Hx(:), Field2.Hy(:), Field2.Hz(:)]);
else
    Q2 = transpose(abs(Field2));
end
err_pntwise = abs(Q1 - Q2);

[flow_H, flow_rec_H, flow_error_H] = Visualization_GG(h_Ph,h_Th,Q1,Q2,err_pntwise,0,0);

end