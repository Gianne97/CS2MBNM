function harm=sph_harmon(n,theta,phi)
%
% Computes the real-valued normalized surface spherical harmonics
% for the integer degree n and for all 0 <= m <= n
% harm(m,1) contains even N_{nm} P_n^{m-1}(cos(theta))*cos((m-1)*phi)
% harm(m,2) contains odd N_{nm} P_n^{m-1}(cos(theta))*sin ((m-1)*phi)
%
% L. Klinkenbusch, Univ. of Kiel
% 26. Feb. 2019
%
leg=legendre(n,cos(theta));
% m=0
harm(1,1)=leg(1)*sqrt((2*n+1)/(4*pi));
harm(1,2)=0;
% m=1:n
for m=1:n
    a = (2*n+1)*factorial(n-m);
    b = 2*pi*factorial(n+m);
    C = sqrt(a/b)*leg(m+1);
    harm(m+1,1)=C*cos(m*phi);
    harm(m+1,2)=C*sin(m*phi);
end
end