function bess=sph_bess(n,x)
% Computes the spherical Bessel function for order n
% L. Klinkenbusch, Univ. of Kiel
% 25. Feb. 2019
%
if abs (x) < 1e-10
    if n == 0
        bess=1;
    else
        bess=0;
    end
else
    bess=besselj(n+.5,x)*sqrt(pi/2/x);
end