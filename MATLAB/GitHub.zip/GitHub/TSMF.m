function [m_th,m_ph] = TSMF(th,ph, l,m)
% TSMF stands for transverse spherical multipole functions
% I consider the Alternative Definition of Phi and Theta Angles
% theta and phi are in radians.
% l >= 1 and -l <= m <= l

m_neg = 0;
if m<0
    m = -m;
    m_neg = 1;
end

Plm = legendre(l,cos(th));
if l ~= 0
    Plm = reshape(Plm(m+1,:,:),size(ph));
end

if l-1 >= 0
    Pl_1m = legendre(l-1,cos(th));
    if l == m

    elseif l-1 == 0 % There is no need to reshape the polynomials for this case
        
    else % l-1 > 0
        Pl_1m = reshape(Pl_1m(m+1,:,:),size(ph));
    end
end

a = (2*l+1)*factorial(l-m);
b = 4*pi*factorial(l+m);
C = sqrt(a/b);
% Ylm = C .*Plm .*exp(1i*m*phi);

% For the derivatives, check https://mathworld.wolfram.com/AssociatedLegendrePolynomial.html
if l == 0
    Plm_dth = 0;
elseif l == m
    Plm_dth = (-1)^l .* DFactorial(2*l - 1) .* 0.5*l.*(1 - cos(th).^2).^(0.5*l - 1).*(2.*cos(th).*sin(th));
else % l >= m-1
    Plm_dth = (l.*cos(th).*Plm - (l+m).*Pl_1m).*(1-cos(th).^2).^(-1/2);
end

% xx = linspace(0,pi);
% PPlm = legendre(l,cos(xx));
% PPlm = PPlm(m+1,:,:);
% PPl_1m = legendre(l-1,cos(xx));
% PPl_1m = PPl_1m(m+1,:,:);
% yy = (l.*cos(xx).*PPlm - (l+m).*PPl_1m).*(1-cos(xx).^2).^(-1/2);
% plot(xx,yy)

Ylm_dph = C .*Plm     .*exp(1i*m*ph) .*1i.*m;
Ylm_dth = C .*Plm_dth .*exp(1i*m*ph);

m_th = -(1./sin(th)) .* Ylm_dph;
m_ph = Ylm_dth;

% we should get zero for theta = [0,pi]
m_th(th == 0) = 0;
m_ph(th == 0) = 0;
m_th(th == pi) = 0;
m_ph(th == pi) = 0;

if m_neg
    m_th = (-1)^m * conj(m_th);
    m_ph = (-1)^m * conj(m_ph);
end

end

function DFact = DFactorial(n)
% Double factorial function, n!!
%  https://en.wikipedia.org/wiki/Double_factorial
%
% n!! = 1 for both n == 1 and n == 0.
if isempty(n) || (numel(n) > 1) || (n < 0) || (mod(n,1) ~= 0)
    error('The sky is falling. n must be scalar, non-negative, integer.')
end

DFact = 1;
if n > 1
    start = 1 + mod(n + 1,2); % caters for either parity of n
    DFact = prod(start:2:n);
end
end